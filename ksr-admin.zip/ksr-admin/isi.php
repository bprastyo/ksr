<?php
@$hal=$_GET['hal'];
if(isset($hal)){
include $hal;
}
else{
include '../dist/koneksi.php';
include "page/dashboard.php";
}
?>
