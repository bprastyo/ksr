<?php
include"../dist/koneksi.php";
?>

<!DOCTYPE html>
<html lang="en">

<head>
<style type="text/css">
    #popup {
        width: 100%;
        height: 100%;
        position: fixed;
        background: rgba(0,0,0,.7);
        top: 0;
        left: 0;
        z-index: 9999;
        visibility: hidden;
    }

    .window {
        border-radius: 15%;
        width: 80%;
        height: 100%;
        padding: 5% 10% 10% 10%;
        border-radius: 10px;
        position: top;
        text-align: center;
        margin: auto;
    }
    .window h2 {
        margin: 30px 0 0 0;
    }
    /* Button Close */
    .close-button {
        width: auto;
        height: 20px;
        line-height: 23px;
        background: black;
        border-radius: 4%;
        border: 1px solid #fff;
        display: block;
        text-align: center;
        color: #fff;
        text-decoration: none;
        position: fixed;    
    }

    /* Memunculkan Jendela Pop Up*/
    #popup:target {
        visibility: visible;
    }
</style>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Ksr Admin</title>
    
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="vendor/metisMenu/metisMenu.min.css" rel="stylesheet">
    <link href="vendor/datatables-plugins/dataTables.bootstrap.css" rel="stylesheet">
    <link href="vendor/datatables-responsive/dataTables.responsive.css" rel="stylesheet">
    <link href="vendor/css/sb-admin-2.css" rel="stylesheet">
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <?php
            include "navbar.php";
            include "isi.php";
        ?>

        <hr>
    <!-- /#content -->

    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/highcharts/highcharts.js"></script>
    <script src="vendor/highcharts/exporting.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
    <script src="vendor/metisMenu/metisMenu.min.js"></script>
    <script src="vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="vendor/datatables-plugins/dataTables.bootstrap.min.js"></script>
    <script src="vendor/datatables-responsive/dataTables.responsive.js"></script>
    <script src="vendor/js/sb-admin-2.js"></script>
    <script>
    $(document).ready(function() {
        $('#example').DataTable({
            responsive: true
        });
    });
    </script>
    <script>
    $(document).ready(function() {
        $('#laporan').DataTable({
            responsive: true
        });
    });
    </script>

</body>
</html>