<?php 
    include '../dist/koneksi.php';
    $date=date('Y-m-d');
?>
<div id="page-wrapper">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Tables</h1>
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->
        <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        DataTables Advanced Tables
                    </div>
                    <!-- /.panel-heading -->
                    <div class="panel-body">
                        <!-- KONTEN-->


            <div class="col-lg-12">
                    <div>
<script type="text/javascript">
  var chart1; // globally available
$(document).ready(function() {
      chart1 = new Highcharts.Chart({
         chart: {
            renderTo: 'container',
            type: 'column'
         },   
         title: {
            text: 'Grafik Penjualan '
         },
         xAxis: {
            categories: ['Item']
         },
         yAxis: {
            title: {
               text: 'Jumlah Terjual'
            }
         },
              series:             
            [

            <?php 

$lapstok=mysqli_query($connect,"select distinct (namaitem)as ni, total from tb_detail_transaksi where tanggalpembelian='$date' AND keterangan='1' order by namaitem ASC") or die($connect);
while($tampil_laporan_stok=mysqli_fetch_array($lapstok)){

$count=mysqli_query($connect,"select sum(jumlahpembelian)as ni, total from tb_detail_transaksi where namaitem='$tampil_laporan_stok[0]' AND tanggalpembelian='$thn_hr-$bln_hr-$tgl_hr' AND keterangan='1'") or die($connect);

$tampil_count=mysqli_fetch_array($count) or die($connect);           
                  ?>
                  {
                      name: '<?php echo $tampil_laporan_stok[0]; ?>',
                      data: [<?php echo $tampil_count[0]; ?>]
                  },
                  <?php } ?>
            ]
      });
   });  
</script>
<div id='container' style="width: 100%; height: 60%;"></div>  
</div>

            </div>




                        <!-- /.table-responsive -->
                    </div>
                    <!-- /.panel-body -->
                </div>
                <!-- /.panel -->
            </div>
            <!-- /.col-lg-12 -->
        </div>
</div>
