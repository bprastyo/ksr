  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  

   <br />
   <h2 align="center">Form Tambah Menu</h2>
   <br />
   <div class="table-responsive">
    <table class="table table-bordered" id="crud_table">
     <tr>
      <th width="30%">Nama Menu</th>
      <th width="10%">Jenis</th>
      <th width="10%">Harga</th>
      <th width="5%"></th>
     </tr>
     <tr>
      <td contenteditable="true" class="nama_item" autofocus="autofocus" placeholder="Menu"></td>
      <td contenteditable="true" class="jenis" placeholder="Kategori">
        <select class="btn btn-md">
          <?php
            include '../dist/koneksi.php';
            $query=mysqli_query($connect,"SELECT * FROM `tb_kategori_item`") or die($connect);
            while($tampil=mysqli_fetch_array($query)){
          ?>
              <option value="<?php echo $tampil['nama_kategori'];?>">
                <?php echo $tampil['nama_kategori'];?>
              </option>
          <?php }?>
      </select></td>
      <td contenteditable="true" class="harga" placeorder="Harga"></td>
      <td align="right"></td>
     </tr>
    </table>
    <div align="right">
     <button type="button" name="add" id="add" class="btn btn-success btn-lg">+</button>
    </div>
    <div align="center">
     <button type="button" name="save" id="save" class="btn btn-info btn-lg">Save</button>
    </div>
    <br />
    <div id="inserted_item_data"></div>
   </div>
   
 </body>
</html>

<script>
$(document).ready(function(){
 var count = 1;
 $('#add').click(function(){
  count = count + 1;
  var html_code = "<tr id='row"+count+"'>";
   html_code += "<td contenteditable='true' class='nama_item'></td>";
   html_code += "<td contenteditable='true' class='jenis'><select class=btn btn-md btn-info><?php $query=mysqli_query($connect,"SELECT * FROM `tb_kategori_item`");            while($tampil=mysqli_fetch_array($query)){ ?><option value=<?php echo $tampil[1];?>><?php echo $tampil[1];?></option><?php }?></select></td>";

   html_code += "<td contenteditable='true' class='harga'></td>";
   html_code += "<td><button type='button' name='remove' data-row='row"+count+"' class='btn btn-danger btn-md remove'>--</button></td>";   
   html_code += "</tr>";  
   $('#crud_table').append(html_code);
 });
 
 $(document).on('click', '.remove', function(){
  var delete_row = $(this).data("row");
  $('#' + delete_row).remove();
 });
 
 $('#save').click(function(){
  var nama_item = [];
  var jenis = [];
  var harga = [];
  $('.nama_item').each(function(){
   nama_item.push($(this).text());
  });
  $('.jenis').each(function(){
   jenis.push($(this).text());
  });
  $('.harga').each(function(){
   harga.push($(this).text());
  });
  $.ajax({
   url:"page/menusimpan.php",
   method:"POST",
   data:{nama_item:nama_item, jenis:jenis, harga:harga},
   success:function(data){
    alert(data);
    $("td[contentEditable='true']").text("");
    for(var i=2; i<= count; i++)
    {
     $('tr#'+i+'').remove();
    }
    fetch_item_data();
   }
  });
 });
});
</script>

