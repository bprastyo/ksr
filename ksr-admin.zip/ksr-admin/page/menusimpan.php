<?php
include '../../dist/koneksi.php';
//insert.php
if(isset($_POST["nama_item"]))
{
 $nama_item = $_POST["nama_item"];
 $jenis = $_POST["jenis"];
 $harga = $_POST["harga"];
 $tanggal= date('Y-m-d');
 $keterangan = 1;
 $query = '';
 for($count = 0; $count<count($nama_item); $count++)
 {
  $nama_item_clean = mysqli_real_escape_string($connect, $nama_item[$count]);
  $jenis_clean = mysqli_real_escape_string($connect, $jenis[$count]);
  $harga_clean = mysqli_real_escape_string($connect, $harga[$count]);
  if($nama_item_clean != '' && $jenis_clean != '' && $harga_clean != '')
  {
   $query = '
   INSERT INTO tb_item(id,nama_item, jenis,harga,tgl_input,ket) 
   VALUES(NULL,"'.$nama_item_clean.'", "'.$jenis_clean.'", "'.$harga_clean.'","'.$tanggal.'","'.$keterangan.'")';
  }
 }
 if($query != '')
 {
  if(mysqli_multi_query($connect, $query) or die($connect))
  {
   echo 'Item Data Inserted';
  }
  else
  {
   echo 'Barbar';
  }
 }
 else
 {
  echo 'All Fields are Required';
 }
}


//include "../koneksi.php";

//$nama		=$_POST['nama'];
//$jenis		=$_POST['jenis'];
//$spesifikasi=$_POST['spesifikasi'];
//$harga		=$_POST['harga'];
//$tgl		=date('Y-m-d');
//mysql_query("INSERT INTO `tb_item` (`id`, `id_item`, `nama_item`, `jenis`, `spesifikasi_jenis`, `harga`, `tgl_input`, `ket`) VALUES (NULL, '', '$nama', '$jenis', '$spesifikasi', '$harga', '$tgl', '1')") or die(mysql_error());
//header('location:../index.php?hal=page/showmenu.php');

?>