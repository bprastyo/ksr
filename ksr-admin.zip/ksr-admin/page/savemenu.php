<?php
include "../koneksi.php";

$nama		=$_POST['nama'];
$jenis		=$_POST['jenis'];
$spesifikasi=$_POST['spesifikasi'];
$harga		=$_POST['harga'];
$tgl		=date('Y-m-d');
mysql_query("INSERT INTO `tb_item` (`id`, `id_item`, `nama_item`, `jenis`, `spesifikasi_jenis`, `harga`, `tgl_input`, `ket`) VALUES (NULL, '', '$nama', '$jenis', '$spesifikasi', '$harga', '$tgl', '1')") or die(mysql_error());
header('location:../index.php?hal=page/showmenu.php');

?>