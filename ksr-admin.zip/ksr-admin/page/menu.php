
<script src="vendor/js/jquery.min.js"></script> 
<div id="page-wrapper">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Data Menu</h1>
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->
        <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        Menampilkan Semua Menu Yang Tersimpan di Database. |
                        <button type="button" class="btn btn-success" data-toggle="modal" data-target="#tambah">tambah data</button>
                        <div id="tambah" class="modal fade modal-admin" role="dialog">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                   <?php include 'page/menuform.php';?>
                                </div>
                            </div>
                        </div>

                        |<a href="?hal=page/menuimport.php"> Import Excel </a>
                    </div>
                    <!-- /.panel-heading -->
                    <div class="panel-body">
<body>
<div class="row">
    <div class="col-md-12">
        <div class=" scroll3">
            <!-- /.panel-heading -->
            <div class="panel-body">

    <form method="post" action="page/menudelete.php" id="form-delete">
        <button type="button" id="btn-delete">DELETE</button>
                <table width="100%" class="table table-striped table-bordered table-hover" id="laporan">
                    <thead>
                        <tr>
                            <td><input type="checkbox" id="check-all"></td>
                        	<th>Item Menu</th>
                            <th>Kategori</th>
                            <th>Harga</th>
                            <th>Status</th>
                            <th>Opsi</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php 
                    
                    $hitung=1;
                    $query_ambil=mysqli_query($connect,"select * from tb_item order by nama_item asc") or die($connect);
                    while($value=mysqli_fetch_array($query_ambil)){
                        
                    ?>
                        <tr>
                            <td><input type="checkbox" class="check-item" name="id[]" value="<?php echo $value['0']; ?>"></td>
                            <td><?php echo $value['nama_item']; ?></td>
                            <td><?php echo $value['jenis']; ?></td>
                            <td align="right"><?php echo $value['harga']; ?>&nbsp;</td>
                            <td align="center">
                            	<?php 
		                             if($value['ket']==1){
		                            		echo $value['ket']." &nbsp; | &nbsp; <a href=page/menunonaktifkan.php?id=".$value['0']."><i class='fa fa-edit'></i> Ubah </a>";
		                            	}else{
		                            		echo "<font color=red>".$value['ket']."</font> &nbsp; | &nbsp; <a href=page/menuaktifkan.php?id=".$value['0']."><i class='fa fa-edit'></i> Ubah </a>";
	                            	}

                              ?></td>
                            <td align="center">
                            	<a href="#"><i class="fa fa-wrench"></i> Edit</a> | 
                            	<a href="page/menuhapus.php?id=<?php echo $value['0'];?>" 
                                    onClick="return confirm('<?php echo "Anda yakin akan menghapus ".$value['2']." dari menu?";?>')" class="fa fa-trash"> Delete</a>



                            </td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>
                </form>
    
    <script>
    $(document).ready(function(){ // Ketika halaman sudah siap (sudah selesai di load)
        $("#check-all").click(function(){ // Ketika user men-cek checkbox all
            if($(this).is(":checked")) // Jika checkbox all diceklis
                $(".check-item").prop("checked", true); // ceklis semua checkbox siswa dengan class "check-item"
            else // Jika checkbox all tidak diceklis
                $(".check-item").prop("checked", false); // un-ceklis semua checkbox siswa dengan class "check-item"
        });
        
        $("#btn-delete").click(function(){ // Ketika user mengklik tombol delete
            var confirm = window.confirm("Apakah Anda yakin ingin menghapus data-data ini?"); // Buat sebuah alert konfirmasi
            
            if(confirm) // Jika user mengklik tombol "Ok"
                $("#form-delete").submit(); // Submit form
        });
    });
    </script>
                <!-- /.table-responsive -->
            </div>
            <!-- /.panel-body -->
        </div>
        <!-- /.panel -->
    </div>
    <!-- /.col-lg-8 -->

            </div>



    <!-- Page-Level Demo Scripts - Tables - Use for reference -->
    

</body>
  </div>
                    <!-- /.panel-body -->
                </div>
                <!-- /.panel -->
            </div>
            <!-- /.col-lg-12 -->
        </div>
</div>