<div id="page-wrapper">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Tables</h1>
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->
        <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        DataTables Advanced Tables
                    </div>
                    <!-- /.panel-heading -->
                    <div class="panel-body">



<div class="modal-header">
<button type="button" class="close" data-dismiss="modal">x</button>
<h4 class="modal-tittle">Tambah Kategori</h4>
</div>

<form method="post" action="#" enctype="multipart/form-data">
<table width="100%"border="1" bordercolor="#00CCFF" cellpadding="0" cellspacing="0">
  <tr>
    <td width="112" height="34">&nbsp;Nama Kategori</td>
    <td width="235"><input name="kategori_nama" id="kategori_nama" type="text" size="30" required="required" Placeholder="Isikan Nama Item" onclick="checkName()" /></td>
  </tr>
  <tr>
    <td height="38">&nbsp;Gambar</td>
    <td><input name="gambar" type="file" size="30"required="required"  placeholder="File : JPG, PNG max 1 MB"></td>
  </tr>
  <tr>
    <td height="38" colspan="2" valign="middle" align="center">
	<input type="submit" value="Simpan" name="simpan">
  </tr>
</table>
<br>
</form>

<?php 
	if(@$_POST['simpan']){
		@$nama=$_POST['kategori_nama'];

		$extensi = explode(".",$_FILES['gambar']['name']);
		$gambar  = "kat-".round(microtime(true)).".".end($extensi);
		$sumber  = $_FILES['gambar']['tmp_name'];
		$upload  = move_uploaded_file($sumber, "../images/".$gambar);

		if($upload){
			$query = mysqli_query($connect,"INSERT INTO tb_kategori_item
									values('','$nama','$gambar')
				") or die($connect);
			@header('location:../index.php?hal=page/kategoritambah.php');
		}else{
			echo "gagal upload";
		}
	}
?>
 </div>
                    <!-- /.panel-body -->
                </div>
                <!-- /.panel -->
            </div>
            <!-- /.col-lg-12 -->
        </div>
</div>