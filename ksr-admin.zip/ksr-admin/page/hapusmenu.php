<?php
include "../koneksi.php";
$id				=$_GET['id'];
mysql_query("DELETE FROM `tb_item` WHERE `tb_item`.`id` = '$id'")or die(mysql_error());
	echo("<script>document.location='../index.php?hal=page/showmenu.php';</script>");
?>