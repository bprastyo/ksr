
<?php
include "../../dist/koneksi.php";
$id			=$_GET['id'];

mysqli_query($connect,"UPDATE `tb_item` SET `ket` = '0' WHERE `tb_item`.`id` =$id")or die($connect);
	echo("<script>document.location='../index.php?hal=page/menu.php';</script>");
?>