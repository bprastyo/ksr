<body style="background-color: white"></body>
<br>
<br>
<table width="70%" align="center"   style="border-style: solid;" bgcolor="white">
	<thead>
	<tr>
		<th colspan="3" align="center">Daftar Kategori Menu<hr></th>
	</tr>
	</thead>
	<tr>
		<td>Id Kategori</td>
		<td>Nama Kategori</td>
		<td>Gambar</td>
	</tr>

<?php
	$query=mysqli_query($connect,"SELECT * FROM `tb_kategori_item` order by nama_kategori ASC") or die($connect);
	while($tampil=mysqli_fetch_array($query)){
		?>
	<tr>
		<td><?php echo $tampil['id_kategori_item'];?></td>
		<td><?php echo $tampil['nama_kategori'];?></td>
		<td><?php echo $tampil['gambar'];?></td>
	</tr>
		<?php
	}
?>
</table>
<hr>
<form method="post" action="#">
	<table width="70%" align="center" style="border-style: solid;" bgcolor="white">
		<tr>
			<th colspan="4" align="center">
				<hr>Form Tambah Kategori Menu<hr>
			</th>
		</tr>
		<tr>
			<td>Nama kategori</td><td><input type="text" name="nama_kategori"></td>
			<td>Gambar</td><td><input type="text" name="gambar"></td>

		</tr>
		<tr>
			<td colspan="4" align="center"><input type="submit" name="" value="Simpan Kategori"></td>
		</tr>
	</table>
</form>