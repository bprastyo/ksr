
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Data member Warkop Koboi Harapan Indah</title>
<style type="text/css">
<!--
.style1 {font-size: 24px;font-weight: bold;}
body,td,th {font-family: Arial, Helvetica, sans-serif;}
.style3 {font-size: 15px}
.scroll{width:auto; overflow:scroll; height:700px;}
.style4 {font-size: 18px}
a{ border:none; background-color:#CCCCCC; clear:both; width:100%; height:max; cursor:pointer;}
</style>
<script src="../ajax.js" ></script>
</head>
<body>
<h2><strong>
<div style="background-color:#CCCCCC; height:40px;"><p align="center">Data Member Warkop Koboi Harapan Indah</p> </div>
</strong></h2>
<table  width="100%" height="566" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#00CCFF" bgcolor="#CCCCCC">
<tr><td width="71%" height="514" valign="top"> <div class="scroll">

<table width="100%" border="1" bordercolor="#00CCFF" cellpadding="0" cellspacing="0" align="left" bgcolor="#FFFFFF">
  <tr class="style3" bgcolor="#999999">
    <td width="19%" align="center" valign="middle"><strong><a href="" onClick="urutnama()"><span class="style4">Nama Item</span></a></strong></td>
    <td width="16%"  align="center" valign="middle"><strong><button onClick="urutjenis()" value="Jenis"><span class="style4">Jenis</span></button></strong></td>
    <td width="16%"  align="center" valign="middle"><strong><button onClick="urutspek()" value="Nama Item"><span class="style4">Spes. Jenis</span></button></strong></td>
    <td width="15%"  height="38" align="center" valign="middle"><strong><button onClick="urutHarga()" value="harga"><span class="style4">Harga</span></button></strong></td>
    <td width="18%"  height="38" align="center" valign="middle"><strong><button onClick="urutstatus()" value="status"><span class="style4">Status</span></button></strong></td>
    <td width="16%"  align="center" valign="middle"><strong><button value="option"><span class="style4">Option</span></button></strong></td>
  </tr>
 
            <?php 
			include "../koneksi.php";
			$warna1="#FFFFFF";
			$warna2="#CCCCCC";
			$hitung=1;
			$query_ambil=mysql_query("select * from tb_item order by jenis asc") or die(mysql_error());
			while($value=mysql_fetch_array($query_ambil)){
				
			?> <!-- Melakukan Perulangan -->
              			
				<tr <?php 
				if($hitung % 2==0){
				echo "bgcolor=#FFFFFF";
				}else{
				echo "bgcolor=#CCCCCC";
				}
				?>>
                    <td height="30" align="left" p>&nbsp;&nbsp;<?php echo $value['2']; ?></td>
                    <td p align="left">&nbsp;<?php echo $value['3'] ?></td>
                    <td p align="Center"><?php echo $value['4']; ?></td>
                    <td p align="center"><?php echo $value['5'] ?></td>
                    <td p align="center">
					<?php $status=$value['7'];
					if($status=="1"){
					echo "<font color=blue><b>Menu Aktif</b></font>";
					echo "&nbsp;&nbsp;|| <a href=menu/nonaktifkanmenu.php?id=".$value['0']."><font color=red>Nonaktifkan</font></a>"; 
					}else{
					echo "<font color=red><b>Menu Nonaktif</b></font>";
					echo "&nbsp;&nbsp;|| <a href=menu/aktifkanmenu.php?id=".$value['0']."><font color=Blue>Aktifkan Menu</font></a>"; 
					}
					 ?>?</td>
                    <td p align="center">
                        <a href="javascript:void()" onClick="editmenu2(<?php echo $value['0'];?> )"style="text-decoration:none; color:#000000">Edit</a> || 
                        <a href="menu/hapusmenu.php?id=<?php echo $value['0']?>" style="text-decoration:none; color:#000000" onClick="return confirm('Anda Yakin Akan Menghapus Data Ini?')">Delete</a>                    </td>
                </tr>
			
			<?php $hitung++;}?>	

</table></div>
</td><td width="29%" valign="top">
<form method="post" action="menu/savemenu.php">
<table width="353"border="1" bordercolor="#00CCFF" cellpadding="0" cellspacing="0" align="right">
  <tr style="background:#666; color:#FF0;">
    <td height="31" colspan="2"><div align="center" class="style1">Tambah Menu </div></td>
  </tr>
  <tr>
    <td width="112" height="34">&nbsp;Nama Item </td>
    <td width="235"><input name="nama" type="text" class="style3" size="30" required="required"></td>
  </tr>
  <tr>
    <td height="34">&nbsp;Jenis</td>
    <td><select class="style3" required="required" name="jenis">
		<option value="angkringan">Angkringan</option>
		<option value="gorengan">Gorengan</option>
		<option value="icecreamfloat">Ice Cream Float</option>
		<option value="indomie">Indomie</option>
		<option value="jus">Jus</option>
		<option value="kbh">KBH</option>
		<option value="kopihitam">Kopi Hitam</option>
		<option value="kopisusu">Kopi Susu</option>
		<option value="Lain-lain">Lain-Lain</option>
		<option value="milkshake">Milkshake</option>
		<option value="pancake">Pancake</option>
		<option value="pisangbakar">Pisang Bakar</option>
		<option value="rotibakar">Roti Bakar</option>
		<option value="sosis">Sosis</option>
		<option value="squash">Squash</option>
		<option value="teh">Teh</option>
		</select>
	</td>
  </tr>	
  <tr>
    <td height="53">Spesifikasi</td>
    <td>
	<input name="spesifikasi" type="radio" class="style3" size="30"required="required" value="makanan" checked="checked">
	Makanan
	<input name="spesifikasi" type="radio" class="style3" size="30"required="required" value="minuman">
	Minuman</td>
  </tr>
  <tr>
    <td height="38">&nbsp;Harga</td>
    <td><input name="harga" type="text" class="style3" size="30"required="required"></td>
  </tr>
  <tr>
    <td height="38" colspan="2">
	<input type="submit" class="style3" value="Simpan">
	<input type="reset" class="style3" value="Reset Data">	</td>
  </tr>
</table>
<br>
</form>
<br>
<br><br>
<br>

<div id="edit" class="style1"><!-- ini isi -->
<br>
<br>

</div>
</td></tr></table>
</body>
</html>