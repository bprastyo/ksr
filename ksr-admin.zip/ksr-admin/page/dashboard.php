<?php
$tanggal = date('Y-m-d'); 
$lap_harian =mysqli_query($connect,"select sum(jumlahpembelian)as ni,sum(total)as hrg,sum(diskon)as dc from tb_detail_transaksi where tanggalpembelian='$tanggal' AND keterangan='1'") or die($connect);

    $tampil_countall=mysqli_fetch_array($lap_harian) or die($connect);
    echo number_format($tampil_countall[0],0,'','.');
?>

<div id="page-wrapper">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Dashboard Ksr Admin</h1>
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->
        <div class="row">
            <div class="col-lg-6">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        Laporan Penjualan <b><?=$tanggal;?> | 
      <?php 
        $query=mysqli_query($connect,"select *, sum(totalpembelian) as total from tb_transaksi where tglpembelian='$tanggal' AND ket='1' order by idtransaksi ASC") or die(mysqli_error($connect));
        while($tampil=mysqli_fetch_array($query)){
          echo "Rp. ".number_format($tampil['total']);
        }?></b>
                    </div>
                    <!-- /.panel-heading -->
                    <div class="panel-body">


<table width="100%">
 <tr >
	    <td align="center">
	    	Qty :
	    </td>
	    <td><?php echo number_format($tampil_countall[1]+$tampil_countall[1],0,'','.');?></td>
	    <td align="center">
	    	Total
	    </td>
	    <td><?php echo number_format($tampil_countall[1],0,'','.');?></td>
	</tr>
	<tr>
		<td colspan="4"><hr><a href="?hal=page/laporan_detail_transaksi.php">Lihat Detail</a></td>
	</tr>
</table>

       <!-- /.table-responsive -->
                    </div>
                    <!-- /.panel-body -->
                </div>
                <!-- /.panel -->
            </div>
            <!-- /.col-lg-12 -->
        </div>
</div>