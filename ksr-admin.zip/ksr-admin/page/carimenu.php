<script src="INC/ajax.js"></script>
<link href="INC/style.css" rel="stylesheet" type="text/css" />			
			
<table width="100%" border="1" bordercolor="#00CCFF" cellpadding="0" cellspacing="0" align="left" bgcolor="#FFFFFF">
  <tr class="style3" bgcolor="#999999">
    <td width="23%" align="center" valign="middle"><strong>
      <button onClick="urutnama()" value="Nama Item"><span class="style4">Nama Item</span></button>
    </strong></td>
    <td width="12%"  align="center" valign="middle"><strong>
      <button onClick="urutjenis()" value="Jenis"><span class="style4">Jenis</span></button>
    </strong></td>
    <td width="14%"  align="center" valign="middle"><strong>
      <button onClick="urutspek()" value="Nama Item"><span class="style4">Spes. Jenis</span></button>
    </strong></td>
    <td width="14%"  height="38" align="center" valign="middle"><strong>
      <button onClick="urutHarga()" value="harga"><span class="style4">Harga</span></button>
    </strong></td>
    <td width="21%"  height="38" align="center" valign="middle"><strong>
      <button onClick="urutstatus()" value="status"><span class="style4">Status</span></button>
    </strong></td>
    <td width="16%"  align="center" valign="middle"><strong>
      <button value="option"><span class="style4">Option</span></button>
    </strong></td>
  </tr>
  <tr>
  <?php 
			include "../koneksi.php";
			$hitung=1;
			$cari=$_POST['cari'];
			$query_ambil=mysql_query("SELECT *
FROM `tb_item`
WHERE `nama_item` LIKE '%$cari%' order by nama_item asc") or die(mysql_error());
			while($value=mysql_fetch_array($query_ambil)){
				
			?>
  <!-- Melakukan Perulangan -->
  <tr <?php 
				if($hitung % 2==0){
				echo "bgcolor=#FFFFFF";
				}else{
				echo "bgcolor=#CCCCCC";
				}
				?>>
    <td height="40" align="left" p>&nbsp;&nbsp;<?php echo $value['2']; ?></font></td>
    <td p align="left">&nbsp;<?php echo $value['3'] ?></td>
    <td p align="Center"><?php echo $value['4']; ?></td>
    <td p align="center"><?php echo $value['5'] ?></td>
    <td p align="center"><?php $status=$value['7'];
					if($status=="1"){
					echo "<font color=blue><b>Menu Aktif</b></font>";
					echo "&nbsp;&nbsp;|| <a href=menu/nonaktifkanmenu.php?id=".$value['0']."><font color=red>Nonaktifkan</font></a>"; 
					}else{
					echo "<font color=red><b>Menu Nonaktif</b></font>";
					echo "&nbsp;&nbsp;|| <a href=menu/aktifkanmenu.php?id=".$value['0']."><font color=Blue>Aktifkan Menu</font></a>"; 
					}
					 ?>
        <font color="#FF0000"><B>?</B></font></td>
    <td p align="center"><a href="javascript:void()" onClick="editmenu(<?php echo $value['0'];?> )">Edit</a> || <a href="menu/hapusmenu.php?id=<?php echo $value['0']?>" style="text-decoration:none; color:#000000" onClick="return confirm('<?php echo "Anda yakin akan menghapus ".$value['2']." dari menu?";?>')">Delete</a></td>
  </tr>
  <?php $hitung++;}?>
</table>