<?php
@include "../koneksi.php";
$kdmember=$_POST['idmenu'];
$query=mysql_query("select * from tb_item where id='$kdmember'")or die(mysql_error());
$value=mysql_fetch_array($query);
?>
<script src="../ajax.js"></script>
<script src="ajax.js"></script>
<form method="post" action="menu/updatemenu.php">
  <table width="389"border="1" bordercolor="#00CCFF" cellpadding="0" cellspacing="0" align="right">
  <tr style="background:#666; color:#FF0;">
    <td height="31" colspan="2"><div align="center" class="style1">Edit Data Menu</div></td>
  </tr>
  <tr>
    <td width="167" height="34">&nbsp;Nama Item </td>
    <td width="213"><input name="nama" type="text" class="style3" size="30" required="required" value="<?php echo $value['nama_item']; ?>" autofocus="autofocus"></td>
  </tr>
  <tr>
    <td height="34">&nbsp;Jenis</td>
    <td>
	<select class="style3" required="required" name="jenis" >
		<option value="angkringan">Angkringan</option>
		<option value="gorengan">Gorengan</option>
		<option value="icecreamfloat">Ice Cream Float</option>
		<option value="indomie">Indomie</option>
		<option value="jus">Jus</option>
		<option value="kbh">KBH</option>
		<option value="kopihitam">Kopi Hitam</option>
		<option value="kopisusu">Kopi Susu</option>
		<option value="Lain-lain">Lain-Lain</option>
		<option value="milkshake">Milkshake</option>
		<option value="pancake">Pancake</option>
		<option value="pisangbakar">Pisang Bakar</option>
		<option value="rotibakar">Roti Bakar</option>
		<option value="sosis">Sosis</option>
		<option value="squash">Squash</option>
		<option value="teh">Teh</option>
		</select>
	
	</td>
  </tr>
  <tr>
    <td height="53">&nbsp;Spesifikasi</td>
    <td>
	<?php
	if($value['spesifikasi_jenis']=="makanan"){
	echo "<input name=spesifikasi type=radio class=style3 size=30 required=required value=makanan checked=checked>Makanan
	<input name=spesifikasi type=radio class=style3 size=30 required=required value=minuman>Minuman";
	}else{
	echo "<input name=spesifikasi type=radio class=style3 size=30 required=required value=makanan>Makanan
	<input name=spesifikasi type=radio class=style3 size=30 required=required value=minuman  checked=checked>Minuman";
	}
	?>	</td>     
  </tr>
  <tr>
    <td height="38">&nbsp;Harga</td>
    <td><input name="harga" type="text" class="style3" size="30"required="required"  value="<?php echo @$value['harga']; ?>"></td>
  </tr>
  <tr>
    <td height="38" colspan="2">
	<input type="submit" class="style3" value="Simpan" onclick="return confirm('Anda Yakin Meng-Edit Data Ini?')">
	<input type="button" class="style3" value="Batal" onClick="tutupmenu()">
	Data ID : <input type="text" readonly="readonly" value="<?php echo $value['id'];?>" name="id"/>	</td>

  </tr>
</table>
</form>
