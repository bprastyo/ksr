
<?php
include "../koneksi.php";
$id			=$_GET['id'];

mysql_query("UPDATE `tb_item` SET `ket` = '1' WHERE `tb_item`.`id` =$id")or die(mysql_error());
	echo("<script>document.location='../index.php?hal=page/showmenu.php';</script>");
?>