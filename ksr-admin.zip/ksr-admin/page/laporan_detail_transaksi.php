<div id="page-wrapper">
        <!-- /.row -->
        <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                             <a href="?hal=page/laporan.php">Laporan Rincian Item Terjual</a> | <a href="?hal=page/laporan_detail_transaksi.php">Laporan Transaksi</a> | <a href="?hal=page/grafik.php">Grafik Penjualan</a>
                    </div>
                    <!-- /.panel-heading -->
                    <div class="panel-body">

<?php
@$tgl=$_POST['tanggal'];
@$bln=$_POST['bulan'];
@$thn=$_POST['tahun'];
if(!isset($tgl)){
$tgl=date("j");
$bln=date("n");
$thn=date("Y");
}
?>
<div align="center"><form action="" method="post" enctype="multipart/form-data" name="labarugi" id="labarugi">
        <table width="600" border="0" cellpadding="0" cellspacing="0">
          <tr>
            <td width="580" align="center" valign="middle">Tanggal :
              <select name="tanggal"  style="height:50px; padding:0px 10px;" id="tanggal">
                <?php
for($a=1;$a<=31;$a++){
?>
                <option value="<?php echo $a;?>" <?php if($a==$tgl){echo "selected='selected'";}?>><?php echo $a;?></option>
                <?php	
	}
?>
              </select>
              Bulan :
              <select name="bulan"  style="height:50px; padding:0px 10px;">
                <?php
$bulan = array("","Januari","Pebruari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember");
for($a=1;$a<=12;$a++){
?>
                <option value="<?php echo $a;?>" <?php if($a==$bln){echo "selected='selected'";}?>><?php echo $bulan[$a];?></option>
                <?php	
	}
?>
              </select>
              Tahun :
              <select name="tahun" style="height:50px; padding:0px 10px;">
                <?php
for($thun=date("Y");$thun>=2000;$thun--){
?>
                <option value="<?php echo $thun;?>"  <?php if($thun==$thn){echo "selected='selected'";}?>><?php echo $thun;?></option>
                <?php	
	}
?>
              </select></td>
            <td width="120" align="center" valign="middle"><input name="button" type="submit" class="button" id="button" style="cursor:pointer; height:50px; padding:0px 10px;" value="Cari" /></td>
          </tr>
        </table>
      </form></div>
<br>
<div>

<div style="overflow:scroll; max-height: 80%; height: 480px">
<table width="100%" border="1" align="center">
  <tr>
    <td colspan="5" align="center">
      <?php 
        $query=mysqli_query($connect,"select *, sum(totalpembelian) as total from tb_transaksi where tglpembelian='$thn-$bln-$tgl' AND ket='1' order by idtransaksi ASC") or die(mysqli_error($connect));
        while($tampil=mysqli_fetch_array($query)){
          echo "<b>Total Nilai Transaksi : Rp. ".number_format($tampil['total'])."</b>";
        }?> | Per Tanggal : <?php echo $tgl." ".$bulan[$bln]." ".$thn;?></td>
    </tr>
  <tr style="background:#666; color:#FF0;">
    <td align="center"><strong>No</strong></td>
    <td align="center"><p><strong>No Nota</strong></p></td>
    <td align="center"><strong>Rincian</strong></td>
    <td align="center"><strong>Waktu</strong></td>
    <td align="center"><strong>Total Transaksi</strong></td>
    </tr>
<?php
$no=1;
$laptransaksi=mysqli_query($connect, "select * from tb_transaksi where tglpembelian='$thn-$bln-$tgl' AND ket='1' order by idtransaksi ASC") or die($connect);
while($tampil_lap_transaksi=mysqli_fetch_array($laptransaksi)){
?>  
  <tr>
    <td align="center"><?php echo $no++;?></td>
    <td align="left" style="padding-left:20px;"><?php echo $tampil_lap_transaksi[1];?></td>
    <td align="center">
          <table width="100%" border="0" cellpadding="0" cellspacing="0" class="lr">
          <tr class="lr" style="color:#FFF">
            <td width="40%" align="center" bgcolor="#999999"><p><strong>Nama Item</strong></p></td>
            <td width="15%" align="right" bgcolor="#999999"><strong>Harga</strong></td>
            <td width="15%" align="center" bgcolor="#999999"><strong>Disc</strong></td>
            <td widht="10%" align="center" bgcolor="#999999"><strong>Qty</strong></td>
            <td widht="20%" align="center" bgcolor="#999999"><strong>Total</strong></td>
          </tr>
                  <?php
                  $lapdetailtransaksi=mysqli_query($connect,"select * from tb_detail_transaksi where iddetailtransaksi='$tampil_lap_transaksi[3]' AND keterangan='1'") or die($connect);
                  while($tampil_lapdetail_transaksi=mysqli_fetch_array($lapdetailtransaksi)){
                  ?>      
          <tr>
            <td><?php echo $tampil_lapdetail_transaksi['namaitem'];?></td>
            <td align="right"><?php echo $tampil_lapdetail_transaksi['harga'];?></td>
            <td align="center"><?php echo $tampil_lapdetail_transaksi['diskon'];?></td>
            <td align="center"><?php echo $tampil_lapdetail_transaksi['jumlahpembelian'];?></td>
            <td align="right"><?php echo $tampil_lapdetail_transaksi['total'];?></td>
          </tr>
                    <?php
                    }
                    ?>
         </table>
    </td>
    <td align="center"><?php echo $tampil_lap_transaksi[7];?><br><?php echo $tampil_lap_transaksi[8];?></td>
    <td align="center"><?php echo number_format($tampil_lap_transaksi[4],0,'','.');?></td>
    </tr>
<?php }?>    
  <tr style="background:#666; color:#FF0;">
    <td colspan="5"  style="border-left:solid 1px #00CCFF;"></td>
    </tr>
</table>
</div>
</div>

    <!-- /.table-responsive -->
                    </div>
                    <!-- /.panel-body -->
                </div>
                <!-- /.panel -->
            </div>
            <!-- /.col-lg-12 -->
        </div>
</div>