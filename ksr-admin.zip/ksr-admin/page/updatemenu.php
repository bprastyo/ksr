<?php
include "../koneksi.php";
$id				=$_POST['id'];
$nama			=$_POST['nama'];
$jenis			=$_POST['jenis'];
$spesifikasi	=$_POST['spesifikasi'];
$harga			=$_POST['harga'];

mysql_query("UPDATE `kasirgw`.`tb_item` SET `nama_item` = '$nama',
`jenis` = '$jenis',
`spesifikasi_jenis` = '$spesifikasi',
`harga` = '$harga' WHERE `tb_item`.`id` ='$id'")or die(mysql_error());

	echo("<script>document.location='../index.php?hal=menu';</script>");
?>