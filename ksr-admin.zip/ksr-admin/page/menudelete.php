<?php
// Load file koneksi.php
include "../../dist/koneksi.php";

$nis = $_POST['id']; // Ambil data NIS yang dikirim oleh index.php melalui form submit
$query = "DELETE FROM tb_item WHERE id IN(".implode(",", $nis).")"; // Buat variabel $query untuk menampung query delete

// Eksekusi/Jalankan query dari variabel $query
mysqli_query($connect, $query);

header("location: ../index.php?hal=page/menu.php"); // Redirect ke halaman index.php
?>

