
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">Data Operator</h1>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
            <div class="container-fluid">
                <div class="row">
                    <table class="table table-bordered">
                        <tr>
                            <th colspan="5">
                                Data Oprerator
                            </th>
                            <th>
                                Tambah data
                            </th>
                        </tr>
                        <tr>
                            <td>No</td>
                            <td>Nama</td>
                            <td>User</td>
                            <td>Role</td>
                            <td>Tanggal daftar</td>
                            <td>Keterangan</td>
                            <td>Opsi</td>
                        </tr>
                        <?php $connect=mysqli_connect("localhost","root","","bootstrap");

                        $query = mysqli_query($connect,"SELECT * FROM `operator` order by id_operator asc") or die($connect);
                        while($tampil=mysqli_fetch_array($query)){
                        ?>
                        <tr>
                            <td><?=$tampil['id_operator'];?></td>
                            <td><?=$tampil['nama_operator'];?></td>
                            <td><?=$tampil['username_operator'];?></td>
                            <td><?=$tampil['role_operator'];?></td>
                            <td><?=$tampil['tanggal_daftar'];?></td>
                            <td><?=$tampil['keterangan'];?></td>
                            <td>Opsi</td>
                        </tr>
                    <?php }?>
                    </table>
                </div>
            </div>
        </div>