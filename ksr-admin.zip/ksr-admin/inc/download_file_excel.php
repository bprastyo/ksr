<?php
mysql_connect("localhost","root","koboi1234");
mysql_select_db("warkop_angkringan_122014");
$bulan = array("","Januari","Pebruari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember");
@$tgl=$_GET['tanggal'];
@$bln=$_GET['bulan'];
@$thn=$_GET['tahun'];
@$nama_file="Detail_Transaksi_".$tgl."_".$bulan[$bln]."_".$thn;
?>
<style>
body {
     font-family:Verdana, Arial, Helvetica, sans-serif; font-size:9px;	
	}
.lr{
	font-size:12px;
	border:solid 1px #00CCFF;	
	}
.lr tr td{
	border-bottom:solid 1px #00CCFF;
	padding:5px 2px;
	}
</style>
<?php /*?><?php
header("Content-type: application/vnd-ms-excel");
header("Content-Disposition: attachment; filename=$nama_file.xls");
?><?php */?>
<table width="80%" border="0" align="center" cellpadding="0" cellspacing="0" class="lr">
  <tr>
    <td colspan="5" align="center" valign="middle"><p><strong> Laporan Detail Transaksi Warkop Koboi Jatiasih</strong></p></td>
    </tr>
  <tr>
    <td colspan="5" align="center">Per Tanggal : <?php echo $tgl." ".$bulan[$bln]." ".$thn;?></td>
    </tr>
  <tr style="background:#666; color:#FF0;">
    <td width="89" align="center"><strong>No Urut</strong></td>
    <td width="176" align="center"><p><strong>No Nota</strong></p></td>
    <td width="364" align="center"><strong>Rincian</strong></td>
    <td width="125" align="center"><strong>Tanggal | Jam</strong></td>
    <td width="133" align="center"><strong>Total Transaksi</strong></td>
    </tr>
<?php
$no=1;
$laptransaksi=mysql_query("select * from tb_transaksi where tgl_pembelian='$thn-$bln-$tgl' AND ket='1' order by id_transaksi ASC");
while($tampil_lap_transaksi=mysql_fetch_array($laptransaksi)){
?>  
  <tr>
    <td width="89" align="center"><b><?php echo $no++;?></b></td>
    <td width="176" align="left" valign="middle" style="padding-left:20px;"><b><?php echo $tampil_lap_transaksi[1];?></b></td>
    <td width="364" align="center"><table width="100%" border="0" cellpadding="0" cellspacing="0" class="lr">
      <tr class="lr" style="color:#FFF">
        <td align="center" bgcolor="#999999"><p><strong>Nama Item</strong></p></td>
        <td align="center" bgcolor="#999999"><strong>Harga</strong></td>
        <td align="center" bgcolor="#999999"><strong>Disc</strong></td>
        <td align="center" bgcolor="#999999"><strong>Jml</strong></td>
        <td align="center" bgcolor="#999999"><strong>Total</strong></td>
      </tr>
<?php
$lapdetailtransaksi=mysql_query("select * from tb_detail_transaksi where id_detail_transaksi='$tampil_lap_transaksi[3]' AND ket='1'");
while($tampil_lapdetail_transaksi=mysql_fetch_array($lapdetailtransaksi)){
?>      
      <tr>
        <td valign="middle"><?php echo $tampil_lapdetail_transaksi[1];?></td>
        <td align="right" valign="middle"><?php echo $tampil_lapdetail_transaksi[2];?></td>
        <td align="center" valign="middle"><?php echo $tampil_lapdetail_transaksi[3];?></td>
        <td align="center" valign="middle"><?php echo $tampil_lapdetail_transaksi[4];?></td>
        <td align="right" valign="middle"><?php echo $tampil_lapdetail_transaksi[5];?></td>
      </tr>
<?php
}
?>
    </table></td>
    <td width="125" align="center" valign="middle"><b><?php echo $tampil_lap_transaksi[7];?><br><?php echo $tampil_lap_transaksi[8];?></b></td>
    <td width="133" align="center" valign="middle"><b><?php echo $tampil_lap_transaksi[4];?></b></td>
    </tr>
<?php }?>
</table>