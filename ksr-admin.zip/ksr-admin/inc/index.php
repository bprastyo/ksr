<?php
mysql_connect("localhost","root","");
mysql_select_db("kasir");
?>
<style>
a{ text-decoration:none;
	}
</style>
<table width="250" border="0" align="center" cellpadding="0" cellspacing="0" >
  <tr>
    <td align="center" style="font-size:10px; font-family:'Trebuchet MS', Arial, Helvetica, sans-serif; text-decoration:none;">
	    	<a href="?hal=laporancekstok.php"><img src="images/Display.png" width="40" height="40" /><br>
	        <strong>Laporan Penjualan Produk</strong></a>
    </td>
    <td align="center" style="font-size:10px; font-family:'Trebuchet MS', Arial, Helvetica, sans-serif; text-decoration:none;">
	    	<a href="?hal=laporan_detail_transaksi.php"><img src="images/new-data.png" width="40" height="40" /><br>
	        <strong>Laporan Detail Penjualan</strong></a>
    </td>
    <td align="center" style="font-size:10px; font-family:'Trebuchet MS', Arial, Helvetica, sans-serif; text-decoration:none;">
    		<a href="?hal=grafik.php"><img src="images/Chart.png" width="40" height="40" /><br>
		    <strong>Grafik Penjualan</strong></a>
	</td>
  </tr>
</table>
<br>
<br>
<?php
@$hal=$_GET['hal'];
if(isset($hal)){
include $hal;
}
else{
include"laporancekstok.php";
}
?>