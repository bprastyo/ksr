<?php
@$tgl=$_POST['tanggal'];
@$bln=$_POST['bulan'];
@$thn=$_POST['tahun'];
if(!isset($tgl)){
$tgl=date("j");
$bln=date("n");
$thn=date("Y");
}
?>
<style>
body {
     font-family:Verdana, Arial, Helvetica, sans-serif; font-size:9px;	
	}
.lr{
	font-size:12px;
	border:solid 1px #00CCFF;	
	}
.lr tr td{
	border-bottom:solid 1px #00CCFF;
	padding:5px 2px;
	}
.button{
	width:120px;
	}
</style>

<title>.: Laporan Warkop Koboi :.</title>
<div align="center"><form action="" method="post" enctype="multipart/form-data" name="labarugi" id="labarugi">
        <table width="600" border="0" cellpadding="0" cellspacing="0">
          <tr>
            <td width="580" align="center" valign="middle">Tanggal :
              <select name="tanggal"  style="height:50px; padding:0px 10px;" id="tanggal">
                <?php
for($a=1;$a<=31;$a++){
?>
                <option value="<?php echo $a;?>" <?php if($a==$tgl){echo "selected='selected'";}?>><?php echo $a;?></option>
                <?php	
	}
?>
              </select>
              Bulan :
              <select name="bulan"  style="height:50px; padding:0px 10px;">
                <?php
$bulan = array("","Januari","Pebruari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember");
for($a=1;$a<=12;$a++){
?>
                <option value="<?php echo $a;?>" <?php if($a==$bln){echo "selected='selected'";}?>><?php echo $bulan[$a];?></option>
                <?php	
	}
?>
              </select>
              Tahun :
              <select name="tahun" style="height:50px; padding:0px 10px;">
                <?php
for($thun=date("Y");$thun>=2000;$thun--){
?>
                <option value="<?php echo $thun;?>"  <?php if($thun==$thn){echo "selected='selected'";}?>><?php echo $thun;?></option>
                <?php	
	}
?>
              </select></td>
            <td width="120" align="center" valign="middle"><input name="button" type="submit" class="button" id="button" style="cursor:pointer; height:50px; padding:0px 10px;" value="Cari" /></td>
          </tr>
        </table>
      </form></div>
<br>
<div>
<table width="90%" border="0" align="center" cellpadding="0" cellspacing="0" class="lr">
  <tr>
    <td colspan="5" align="center" valign="middle"><p><strong> Laporan Detail Transaksi Warkop Koboi Harapan Indah </strong></p></td>
    </tr>
  <tr>
    <td colspan="5" align="center">Per Tanggal : <?php echo $tgl." ".$bulan[$bln]." ".$thn;?></td>
    </tr>
  <tr style="background:#666; color:#FF0;">
    <td align="center"><strong>No</strong></td>
    <td align="center"><p><strong>No Nota</strong></p></td>
    <td align="center"><strong>Rincian</strong></td>
    <td align="center"><strong>Waktu</strong></td>
    <td align="center"><strong>Total Transaksi</strong></td>
    </tr>
<?php
$no=1;
$laptransaksi=mysql_query("select * from tb_transaksi where tglpembelian='$thn-$bln-$tgl' AND ket='1' order by idtransaksi ASC") or die(mysql_error());
while($tampil_lap_transaksi=mysql_fetch_array($laptransaksi)){
?>  
  <tr>
    <td align="center"><?php echo $no++;?></td>
    <td align="left" style="padding-left:20px;"><?php echo $tampil_lap_transaksi[1];?></td>
    <td align="center">
          <table width="100%" border="0" cellpadding="0" cellspacing="0" class="lr">
          <tr class="lr" style="color:#FFF">
            <td width="40%" align="center" bgcolor="#999999"><p><strong>Nama Item</strong></p></td>
            <td width="15%" align="right" bgcolor="#999999"><strong>Harga</strong></td>
            <td width="15%" align="center" bgcolor="#999999"><strong>Disc</strong></td>
            <td widht="10%" align="center" bgcolor="#999999"><strong>Qty</strong></td>
            <td widht="20%" align="center" bgcolor="#999999"><strong>Total</strong></td>
          </tr>
                  <?php
                  $lapdetailtransaksi=mysql_query("select * from tb_detail_transaksi where iddetailtransaksi='$tampil_lap_transaksi[3]' AND keterangan='1'") or die(mysql_error());
                  while($tampil_lapdetail_transaksi=mysql_fetch_array($lapdetailtransaksi)){
                  ?>      
          <tr>
            <td><?php echo $tampil_lapdetail_transaksi['namaitem'];?></td>
            <td align="right"><?php echo $tampil_lapdetail_transaksi['harga'];?></td>
            <td align="center"><?php echo $tampil_lapdetail_transaksi['diskon'];?></td>
            <td align="center"><?php echo $tampil_lapdetail_transaksi['jumlahpembelian'];?></td>
            <td align="right"><?php echo $tampil_lapdetail_transaksi['total'];?></td>
          </tr>
                    <?php
                    }
                    ?>
         </table>
    </td>
    <td align="center"><?php echo $tampil_lap_transaksi[7];?><br><?php echo $tampil_lap_transaksi[8];?></td>
    <td align="center"><?php echo number_format($tampil_lap_transaksi[4],0,'','.');?></td>
    </tr>
<?php }?>    
  <tr style="background:#666; color:#FF0;">
    <td colspan="5"  style="border-left:solid 1px #00CCFF;"><a href="download_file_excel.php?tanggal=<?php echo $tgl;?>&bulan=<?php echo $bln;?>&tahun=<?php echo $thn;?>" style="text-decoration:none; color:#FFF; font-weight:bold;">Download File Excel</a></td>
    </tr>
</table>
</div>