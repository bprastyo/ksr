<?php
@$tgl_hr=$_POST['tanggal_hr'];
@$bln_hr=$_POST['bulan_hr'];
@$bln_bln=$_POST['bulan_bln'];
@$thn_hr=$_POST['tahun_hr'];
@$thn_bln=$_POST['tahun_bln'];
@$thn_thn=$_POST['tahun_thn'];
if(!isset($tgl_hr)&&!isset($bln_bln)&&!isset($thn_thn)){
$tgl_hr=date("j");
$bln_hr=date("n");
$bln_bln=date("n");
$thn_hr=date("Y");
$thn_bln=date("Y");
$thn_thn=date("Y");
}
?>
<style>
body {
     font-family:Verdana, Arial, Helvetica, sans-serif; font-size:9px;	
	}
.lr{
	font-size:12px;
	border:solid 1px #00CCFF;	
	}
.lr tr td{
	border-bottom:solid 1px #00CCFF;
	padding:5px 2px;
	}

.lr2{
	font-size:12px;
	}
.lr2 tr td{
	padding:5px 2px;
	}
.button{
	width:120px;
	}	
</style>

<title>.: Laporan Stok Warkop Koboii :.</title>
<div align="center">
  <table width="900" border="0" align="center" cellpadding="0" cellspacing="0"  class="lr2">
    <tr>
      <td colspan="3" align="center"><strong>Pencarian</strong></td>
    </tr>
    <tr>
      <td width="394" align="center"><form action="" method="post" enctype="multipart/form-data" name="harian" id="labarugi">
        <table width="390" border="0" cellpadding="0" cellspacing="0" class="lr2">
          <tr>
            <td colspan="2" align="center" valign="middle">Harian</td>
            </tr>
          <tr>
            <td width="476" align="center" valign="middle"><select name="tanggal_hr"  style="height:50px; padding:0px 10px;" id="tanggal_hr">
              <?php
for($a=1;$a<=31;$a++){
?>
              <option value="<?php echo $a;?>" <?php if($a==$tgl_hr){echo "selected='selected'";}?>><?php echo $a;?></option>
              <?php	
	}
?>
            </select>
              <select name="bulan_hr"  style="height:50px; padding:0px 10px;" id="bulan_hr">
                <?php
$bulan = array("","Januari","Pebruari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember");
for($a=1;$a<=12;$a++){
?>
                <option value="<?php echo $a;?>" <?php if($a==$bln_hr){echo "selected='selected'";}?>><?php echo $bulan[$a];?></option>
                <?php	
	}
?>
              </select>
              <select name="tahun_hr" style="height:50px; padding:0px 10px;" id="tahun_hr">
                <?php
for($thun=date("Y");$thun>=2000;$thun--){
?>
                <option value="<?php echo $thun;?>"  <?php if($thun==$thn_hr){echo "selected='selected'";}?>><?php echo $thun;?></option>
                <?php	
	}
?>
              </select></td>
            <td width="124" align="center" valign="middle"><input name="button2" type="submit" class="button" id="button2" style="cursor:pointer; height:50px; padding:0px 10px;" value="Cari" /></td>
          </tr>
        </table>
      </form></td>
      <td width="324" align="center"><form action="" method="post" enctype="multipart/form-data" name="bulanan" id="labarugi">
        <table width="320" border="0" cellpadding="0" cellspacing="0" class="lr2">
          <tr>
            <td colspan="2" align="center" valign="middle">Bulanan</td>
            </tr>
          <tr>
            <td width="476" align="center" valign="middle"><select name="bulan_bln"  style="height:50px; padding:0px 10px;" id="bulan_bln">
              <?php
$bulan = array("","Januari","Pebruari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember");
for($a=1;$a<=12;$a++){
?>
              <option value="<?php echo $a;?>" <?php if($a==$bln_bln){echo "selected='selected'";}?>><?php echo $bulan[$a];?></option>
              <?php	
	}
?>
            </select>
              <select name="tahun_bln" style="height:50px; padding:0px 10px;" id="tahun_bln">
                <?php
for($thun=date("Y");$thun>=2000;$thun--){
?>
                <option value="<?php echo $thun;?>"  <?php if($thun==$thn_bln){echo "selected='selected'";}?>><?php echo $thun;?></option>
                <?php	
	}
?>
              </select></td>
            <td width="124" align="center" valign="middle"><input name="button" type="submit" class="button" id="button" style="cursor:pointer; height:50px; padding:0px 10px;" value="Cari" /></td>
          </tr>
        </table>
      </form></td>
      <td width="352" align="center"><form action="" method="post" enctype="multipart/form-data" name="tahunan" id="labarugi">
        <table width="200" border="0" cellpadding="0" cellspacing="0" class="lr2">
          <tr>
            <td colspan="2" align="center" valign="middle">Tahunan</td>
            </tr>
          <tr>
            <td width="476" align="center" valign="middle"><select name="tahun_thn" style="height:50px; padding:0px 10px;" id="tahun_thn">
              <?php
for($thun=date("Y");$thun>=2000;$thun--){
?>
              <option value="<?php echo $thun;?>"  <?php if($thun==$thn_thn){echo "selected='selected'";}?>><?php echo $thun;?></option>
              <?php	
	}
?>
            </select></td>
            <td width="124" align="center" valign="middle"><input name="button3" type="submit" class="button" id="button3" style="cursor:pointer; height:50px; padding:0px 10px;" value="Cari" /></td>
          </tr>
        </table>
      </form></td>
    </tr>
    <tr>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
    </tr>
  </table>
</div>
<br>
<br>
<br>
<div>
<script src="js/jquery.min.js" type="text/javascript"></script>
<script src="js/highcharts.js" type="text/javascript"></script>
<script type="text/javascript">
	var chart1; // globally available
$(document).ready(function() {
      chart1 = new Highcharts.Chart({
         chart: {
            renderTo: 'container',
            type: 'column'
         },   
         title: {
            text: 'Grafik Penjualan Warkop Koboi '
         },
         xAxis: {
            categories: ['Item']
         },
         yAxis: {
            title: {
               text: 'Jumlah Terjual'
            }
         },
              series:             
            [
            <?php 
if(isset($tgl_hr)){
$lapstok=mysql_query("select distinct (namaitem)as ni, total from tb_detail_transaksi where tanggalpembelian='$thn_hr-$bln_hr-$tgl_hr' AND keterangan='1' order by namaitem ASC") or die(mysql_error());
}
else if(isset($bln_bln)){
$lapstok=mysql_query("select distinct (namaitem)as ni, total from tb_detail_transaksi where MONTH(tanggalpembelian)='$bln_bln' AND YEAR(tanggalpembelian)='$thn_bln' AND keterangan='1' order by namaitem ASC") or die(mysql_error());
}
else if(isset($thn_thn)){
$lapstok=mysql_query("select distinct (namaitem)as ni, total from tb_detail_transaksi where YEAR(tanggalpembelian)='$thn_thn' AND keterangan='1' order by namaitem ASC") or die(mysql_error());
}
while($tampil_laporan_stok=mysql_fetch_array($lapstok)){

if(isset($tgl_hr)){
$count=mysql_query("select sum(jumlahpembelian)as ni, total from tb_detail_transaksi where namaitem='$tampil_laporan_stok[0]' AND tanggalpembelian='$thn_hr-$bln_hr-$tgl_hr' AND keterangan='1'") or die(mysql_error());
}
else if(isset($bln_bln)){
$count=mysql_query("select sum(jumlahpembelian)as ni, total from tb_detail_transaksi where namaitem='$tampil_laporan_stok[0]' AND MONTH(tanggalpembelian)='$bln_bln' AND YEAR(tanggalpembelian)='$thn_bln' AND keterangan='1'") or die(mysql_error());
}
else if(isset($thn_thn)){
$count=mysql_query("select sum(jumlahpembelian)as ni, total from tb_detail_transaksi where namaitem='$tampil_laporan_stok[0]' AND YEAR(tanggalpembelian)='$thn_thn' AND keterangan='1'") or die(mysql_error());
}
$tampil_count=mysql_fetch_array($count) or die(mysql_error());           
                  ?>
                  {
                      name: '<?php echo $tampil_laporan_stok[0]; ?>',
                      data: [<?php echo $tampil_count[0]; ?>]
                  },
                  <?php } ?>
            ]
      });
   });	
</script>
<div id='container' style="width: 100%; height: 60%;"></div>	
</div>
