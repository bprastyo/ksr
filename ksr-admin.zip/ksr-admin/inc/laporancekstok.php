<?php
@$tgl_hr=$_POST['tanggal_hr'];
@$bln_hr=$_POST['bulan_hr'];
@$bln_bln=$_POST['bulan_bln'];
@$thn_hr=$_POST['tahun_hr'];
@$thn_bln=$_POST['tahun_bln'];
@$thn_thn=$_POST['tahun_thn'];
if(!isset($tgl_hr)&&!isset($bln_bln)&&!isset($thn_thn)){
$tgl_hr=date("j");
$bln_hr=date("n");
$bln_bln=date("n");
$thn_hr=date("Y");
$thn_bln=date("Y");
$thn_thn=date("Y");
}
?>
<style>
body {
     font-family:Verdana, Arial, Helvetica, sans-serif; font-size:9px;	
	}
.lr{
	font-size:12px;
	border:solid 1px #00CCFF;	
	}
.lr tr td{
	border-bottom:solid 1px #00CCFF;
	padding:5px 2px;
	}

.lr2{
	font-size:12px;
	}
.lr2 tr td{
	padding:5px 2px;
	}
.button{
	width:120px;
	}	
</style>

<title>.: Laporan Stok Warkop Koboii :.</title>
<div align="center">
  <table width="900" border="0" align="center" cellpadding="0" cellspacing="0"  class="lr2">
    <tr>
      <td colspan="3" align="center"><strong>Pencarian</strong></td>
    </tr>
    <tr>
      <td width="394" align="center"><form action="" method="post" enctype="multipart/form-data" name="harian" id="labarugi">
        <table width="390" border="0" cellpadding="0" cellspacing="0" class="lr2">
          <tr>
            <td colspan="2" align="center" valign="middle">Harian</td>
            </tr>
          <tr>
            <td width="476" align="center" valign="middle"><select name="tanggal_hr"  style="height:50px; padding:0px 10px;" id="tanggal_hr">
              <?php
for($a=1;$a<=31;$a++){
?>
              <option value="<?php echo $a;?>" <?php if($a==$tgl_hr){echo "selected='selected'";}?>><?php echo $a;?></option>
              <?php	
	}
?>
            </select>
              <select name="bulan_hr"  style="height:50px; padding:0px 10px;" id="bulan_hr">
                <?php
$bulan = array("","Januari","Pebruari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember");
for($a=1;$a<=12;$a++){
?>
                <option value="<?php echo $a;?>" <?php if($a==$bln_hr){echo "selected='selected'";}?>><?php echo $bulan[$a];?></option>
                <?php	
	}
?>
              </select>
              <select name="tahun_hr" style="height:50px; padding:0px 10px;" id="tahun_hr">
                <?php
for($thun=date("Y");$thun>=2000;$thun--){
?>
                <option value="<?php echo $thun;?>"  <?php if($thun==$thn_hr){echo "selected='selected'";}?>><?php echo $thun;?></option>
                <?php	
	}
?>
              </select></td>
            <td width="124" align="center" valign="middle"><input name="button2" type="submit" class="button" id="button2" style="cursor:pointer; height:50px; padding:0px 10px;" value="Cari" /></td>
          </tr>
        </table>
      </form></td>
      <td width="324" align="center"><form action="" method="post" enctype="multipart/form-data" name="bulanan" id="labarugi">
        <table width="320" border="0" cellpadding="0" cellspacing="0" class="lr2">
          <tr>
            <td colspan="2" align="center" valign="middle">Bulanan</td>
            </tr>
          <tr>
            <td width="476" align="center" valign="middle"><select name="bulan_bln"  style="height:50px; padding:0px 10px;" id="bulan_bln">
              <?php
$bulan = array("","Januari","Pebruari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember");
for($a=1;$a<=12;$a++){
?>
              <option value="<?php echo $a;?>" <?php if($a==$bln_bln){echo "selected='selected'";}?>><?php echo $bulan[$a];?></option>
              <?php	
	}
?>
            </select>
              <select name="tahun_bln" style="height:50px; padding:0px 10px;" id="tahun_bln">
                <?php
for($thun=date("Y");$thun>=2000;$thun--){
?>
                <option value="<?php echo $thun;?>"  <?php if($thun==$thn_bln){echo "selected='selected'";}?>><?php echo $thun;?></option>
                <?php	
	}
?>
              </select></td>
            <td width="124" align="center" valign="middle"><input name="button" type="submit" class="button" id="button" style="cursor:pointer; height:50px; padding:0px 10px;" value="Cari" /></td>
          </tr>
        </table>
      </form></td>
      <td width="352" align="center"><form action="" method="post" enctype="multipart/form-data" name="tahunan" id="labarugi">
        <table width="200" border="0" cellpadding="0" cellspacing="0" class="lr2">
          <tr>
            <td colspan="2" align="center" valign="middle">Tahunan</td>
            </tr>
          <tr>
            <td width="476" align="center" valign="middle"><select name="tahun_thn" style="height:50px; padding:0px 10px;" id="tahun_thn">
              <?php
for($thun=date("Y");$thun>=2000;$thun--){
?>
              <option value="<?php echo $thun;?>"  <?php if($thun==$thn_thn){echo "selected='selected'";}?>><?php echo $thun;?></option>
              <?php	
	}
?>
            </select></td>
            <td width="124" align="center" valign="middle"><input name="button3" type="submit" class="button" id="button3" style="cursor:pointer; height:50px; padding:0px 10px;" value="Cari" /></td>
          </tr>
        </table>
      </form></td>
    </tr>
    <tr>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
    </tr>
  </table>
</div>
<br>
<br>
<br>
<div>
<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0" class="lr">
  <tr>
    <td colspan="7" align="center" valign="middle"><p><strong> Laporan Barang Kejual Warkop Koboi</strong></p></td>
    </tr>
  <tr>
    <td colspan="7" align="center">Per : <?php if(isset($tgl_hr)){echo $tgl_hr."/".$bulan[$bln_hr]."/".$thn_hr;}else if(isset($bln_bln)){echo $bulan[$bln_bln]."/".$thn_bln;}else if(isset($thn_thn)){echo $thn_thn;};?></td>
    </tr>
  <tr style="background:#666; color:#FF0;">
    <td width="82" align="center"><strong>No Urut</strong></td>
    <td width="389" align="center"><strong>Nama Barang</strong></td>
    <td width="127" align="center"><strong>Jumlah Kejual</strong></td>
    <td width="127" align="center"><p><strong>Harga Per Item</strong></p></td>
    <td width="127" align="center"><strong>Total</strong></td>
    <td width="127" align="center"><strong>Pot. diskon</strong></td>
    <td width="127" align="center"><strong>Total Akhir</strong></td>
    </tr>
<?php
$no=1;
if(isset($tgl_hr)){
$lapstok=mysql_query("select distinct (namaitem)as ni from tb_detail_transaksi where tanggalpembelian='$thn_hr-$bln_hr-$tgl_hr' AND keterangan='1' order by namaitem ASC") or die(mysql_error());
}
else if(isset($bln_bln)){
$lapstok=mysql_query("select distinct (namaitem)as ni from tb_detail_transaksi where MONTH(tanggalpembelian)='$bln_bln' AND YEAR(tanggalpembelian)='$thn_bln' AND keterangan='1' order by namaitem ASC") or die(mysql_error());
}
else if(isset($thn_thn)){
$lapstok=mysql_query("select distinct (namaitem)as ni from tb_detail_transaksi where YEAR(tanggalpembelian)='$thn_thn' AND keterangan='1' order by namaitem ASC") or die(mysql_error());
}
while($tampil_laporan_stok=mysql_fetch_array($lapstok)){
?>  
  <tr>
    <td width="82" align="center"><?php echo $no++;?></td>
    <td width="389" align="left" style="padding-left:20px;"><?php echo $tampil_laporan_stok[0];?></td>
    <td width="127" align="center">
<b><?php
if(isset($tgl_hr)){
$count=mysql_query("select sum(jumlahpembelian)as ni,harga,sum(diskon*jumlahpembelian)as dc from tb_detail_transaksi where namaitem='$tampil_laporan_stok[0]' AND tanggalpembelian='$thn_hr-$bln_hr-$tgl_hr' AND keterangan='1'") or die(mysql_error());
}
else if(isset($bln_bln)){
$count=mysql_query("select sum(jumlahpembelian)as ni,harga,sum(diskon*jumlahpembelian)as dc from tb_detail_transaksi where namaitem='$tampil_laporan_stok[0]' AND MONTH(tanggalpembelian)='$bln_bln' AND YEAR(tanggalpembelian)='$thn_bln' AND keterangan='1'") or die(mysql_error());
}
else if(isset($thn_thn)){
$count=mysql_query("select sum(jumlahpembelian)as ni,harga,sum(diskon*jumlahpembelian)as dc from tb_detail_transaksi where namaitem='$tampil_laporan_stok[0]' AND YEAR(tanggalpembelian)='$thn_thn' AND keterangan='1'") or die(mysql_error());
}
$tampil_count=mysql_fetch_array($count);
echo $tampil_count[0];
?></b>    
    </td>
    <td width="127" align="right"><?php echo number_format($tampil_count[1],0,'','.');?></td>
    <td width="127" align="right"><?php echo number_format($tampil_count[0]*$tampil_count[1],0,'','.');?></td>
    <td width="127" align="right"><?php echo number_format($tampil_count[2],0,'','.');?></td>
    <td width="127" align="right"><?php echo number_format($tampil_count[0]*$tampil_count[1]-$tampil_count[2],0,'','.');?></td>
    </tr>
<?php }?>    
  <tr style="background:#666; color:#FF0;">
    <td colspan="2" align="center"  style="border-left:solid 1px #00CCFF;"><strong>TOTAL LIST DATA</strong></td>
    <td align="center"  style="border-left:solid 1px #00CCFF;"><b><?php
	
if(isset($tgl_hr)){
$countall=mysql_query("select sum(jumlahpembelian)as ni,sum(total)as hrg,sum(diskon)as dc from tb_detail_transaksi where tanggalpembelian='$thn_hr-$bln_hr-$tgl_hr' AND keterangan='1'");
}
else if(isset($bln_bln)){
$countall=mysql_query("select sum(jumlahpembelian)as ni,sum(total)as hrg,sum(diskon)as dc from tb_detail_transaksi where MONTH(tanggalpembelian)='$bln_bln' AND YEAR(tanggalpembelian)='$thn_bln' AND keterangan='1'");
}
else if(isset($thn_thn)){
$countall=mysql_query("select sum(jumlahpembelian)as ni,sum(total)as hrg,sum(diskon)as dc from tb_detail_transaksi where YEAR(tanggalpembelian)='$thn_thn' AND keterangan='1'") or die(mysql_error());
}	
$tampil_countall=mysql_fetch_array($countall) or die(mysql_error());
echo number_format($tampil_countall[0],0,'','.');
?></b></td>
    <td align="right"  style="border-left:solid 1px #00CCFF;">-</td>
    <td align="right"  style="border-left:solid 1px #00CCFF;">Rp. <?php echo number_format($tampil_countall[1]+$tampil_countall[2],0,'','.');?></td>
    <td align="right"  style="border-left:solid 1px #00CCFF;">Rp. <?php echo number_format($tampil_countall[2],0,'','.');?></td>
    <td align="right"  style="border-left:solid 1px #00CCFF;">Rp. <?php echo number_format($tampil_countall[1],0,'','.');?></td>
  </tr>
  </table>
</div>